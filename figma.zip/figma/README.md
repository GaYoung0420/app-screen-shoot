# App Screen Shot Figma Plugin

이 폴더는 웹앱을 Figma 플러그인으로 사용할 수 있게 만든 로컬 플러그인입니다.

## 설치

1. Figma Desktop을 엽니다.
2. `Plugins > Development > Import plugin from manifest...`를 선택합니다.
3. 이 폴더의 `manifest.json`을 선택합니다.

## 사용

1. 플러그인을 실행합니다.
2. MP4, MOV, WebM 화면 녹화 파일을 업로드합니다.
3. `추출 시작`을 눌러 주요 화면을 자동 캡쳐합니다.
4. 필요한 캡쳐를 선택한 뒤 `선택 Figma 배치`를 누르면 현재 Figma 페이지에 이미지 보드가 생성됩니다.

## 참고

- 영상은 외부 서버로 전송되지 않고 플러그인 UI 안에서만 처리됩니다.
- 브라우저가 재생할 수 없는 HEVC 영상은 H.264 MP4로 변환한 뒤 사용하세요.
- `선택 ZIP`은 선택한 PNG를 로컬 ZIP 파일로 저장합니다.
