figma.showUI(__html__, {
  width: 980,
  height: 760,
  themeColors: true
});

var DISPLAY_WIDTH = 220;
var GAP = 32;
var PADDING = 24;
var LABEL_HEIGHT = 24;

function toBytes(value) {
  if (value instanceof Uint8Array) return value;
  if (value instanceof ArrayBuffer) return new Uint8Array(value);
  if (Array.isArray(value)) return new Uint8Array(value);
  return null;
}

function pad2(value) {
  return String(value).length < 2 ? "0" + value : String(value);
}

function formatTime(seconds) {
  if (!Number.isFinite(seconds)) return "00:00";
  var mins = Math.floor(seconds / 60);
  var secs = Math.floor(seconds % 60);
  return pad2(mins) + ":" + pad2(secs);
}

function screenNumber(index) {
  return pad2(index + 1);
}

function getMaxRowHeight(row) {
  var max = 0;
  for (var index = 0; index < row.length; index += 1) {
    if (row[index].height > max) max = row[index].height;
  }
  return max + LABEL_HEIGHT;
}

function sum(values) {
  var total = 0;
  for (var index = 0; index < values.length; index += 1) {
    total += values[index];
  }
  return total;
}

figma.ui.onmessage = async function (message) {
  if (message.type === "resize") {
    figma.ui.resize(message.width, message.height);
    return;
  }

  if (message.type === "notify") {
    figma.notify(message.message);
    return;
  }

  if (message.type !== "create-images") return;

  var images = Array.isArray(message.images) ? message.images : [];
  if (!images.length) {
    figma.notify("가져올 스크린샷을 선택해주세요.");
    return;
  }

  var canLabel = true;
  try {
    await figma.loadFontAsync({ family: "Inter", style: "Regular" });
    await figma.loadFontAsync({ family: "Inter", style: "Medium" });
  } catch (error) {
    canLabel = false;
  }

  var columns = Math.min(4, Math.ceil(Math.sqrt(images.length)));
  var rows = [];
  var currentRow = [];

  for (var imageIndex = 0; imageIndex < images.length; imageIndex += 1) {
    var source = images[imageIndex];
    var sourceWidth = Number(source.width) || DISPLAY_WIDTH;
    var sourceHeight = Number(source.height) || DISPLAY_WIDTH * 1.8;
    var scale = DISPLAY_WIDTH / sourceWidth;

    currentRow.push({
      index: imageIndex,
      name: source.name,
      time: source.time,
      bytes: source.bytes,
      width: DISPLAY_WIDTH,
      height: Math.max(1, sourceHeight * scale)
    });

    if (currentRow.length === columns || imageIndex === images.length - 1) {
      rows.push(currentRow);
      currentRow = [];
    }
  }

  var rowHeights = [];
  for (var rowIndex = 0; rowIndex < rows.length; rowIndex += 1) {
    rowHeights.push(getMaxRowHeight(rows[rowIndex]));
  }

  var boardWidth = PADDING * 2 + columns * DISPLAY_WIDTH + Math.max(0, columns - 1) * GAP;
  var boardHeight = PADDING * 2 + sum(rowHeights) + Math.max(0, rows.length - 1) * GAP;

  var board = figma.createFrame();
  board.name = message.sourceName ? message.sourceName + " screenshots" : "App screenshots";
  board.resize(boardWidth, boardHeight);
  board.fills = [{ type: "SOLID", color: { r: 0.965, g: 0.98, b: 0.976 } }];
  board.clipsContent = false;
  board.x = figma.viewport.center.x - boardWidth / 2;
  board.y = figma.viewport.center.y - boardHeight / 2;

  var y = PADDING;
  var createdCount = 0;

  for (var r = 0; r < rows.length; r += 1) {
    var row = rows[r];

    for (var c = 0; c < row.length; c += 1) {
      var item = row[c];
      var bytes = toBytes(item.bytes);
      if (!bytes) continue;

      var x = PADDING + c * (DISPLAY_WIDTH + GAP);
      var image = figma.createImage(bytes);

      if (canLabel) {
        var label = figma.createText();
        label.name = screenNumber(item.index) + " label";
        label.fontName = { family: "Inter", style: "Medium" };
        label.fontSize = 12;
        label.fills = [{ type: "SOLID", color: { r: 0.09, g: 0.125, b: 0.114 } }];
        label.characters = screenNumber(item.index) + "  " + formatTime(item.time);
        board.appendChild(label);
        label.x = x;
        label.y = y;
      }

      var rect = figma.createRectangle();
      rect.name = item.name || "screen-" + screenNumber(item.index);
      rect.resize(item.width, item.height);
      board.appendChild(rect);
      rect.x = x;
      rect.y = y + LABEL_HEIGHT;
      rect.cornerRadius = 10;
      rect.fills = [{ type: "IMAGE", imageHash: image.hash, scaleMode: "FIT" }];
      rect.strokes = [{ type: "SOLID", color: { r: 0.86, g: 0.91, b: 0.895 } }];
      rect.strokeWeight = 1;
      createdCount += 1;
    }

    y += rowHeights[r] + GAP;
  }

  figma.currentPage.selection = [board];
  figma.viewport.scrollAndZoomIntoView([board]);
  figma.notify(createdCount + "개의 스크린샷을 Figma 캔버스에 배치했습니다.");
  figma.ui.postMessage({ type: "import-complete", count: createdCount });
};
